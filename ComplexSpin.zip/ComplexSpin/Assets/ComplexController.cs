﻿using UnityEngine;
using System;

public class ComplexController : MonoBehaviour {
	private float radian_coversion = (float) (360.0f / (Math.PI * 2.0f ));
	public enum RelationMode {Multiplication, Root, Addition};
	private const float
	hoursToDegrees = 360f / 12f,
	minutesToDegrees = 360f / 60f,
	secondsToDegrees = 360f / 60f;

	public Transform z1, z2, z3;

	public float r1, theta1, r2, theta2;
	public int degree = 1;
	public RelationMode mode;


	void Update () {
		float r3 = 0, theta3 = 0;
		if (degree <= 0) {
			degree = 1;
		}

		z1.transform.localScale = new Vector3(1f, r1 , 1f);
		z1.transform.localPosition = new Vector3 (0, 0, 0);
		z1.transform.localRotation = Quaternion.Euler (0f, 0f, -90+theta1);
		z2.transform.localScale = new Vector3(1f, r2 , 1f);
		z2.transform.localPosition = new Vector3 (0, 0, 0);
		z2.transform.localRotation = Quaternion.Euler (0f, 0f, -90+theta2);

		if (mode == RelationMode.Multiplication) {
			r3 = r1 * r2;
			theta3 = -90+theta1 + theta2;
		} else if (mode == RelationMode.Root) {
			/* Z1^degree = Z3 */
			r3 = (float)Math.Pow ((double)r1, degree);
			theta3 = -90+theta1 * degree;
			z2.transform.localScale = new Vector3 (0, 0, 0);
		} else if (mode == RelationMode.Addition) {
			
			float x_comp, y_comp;
			x_comp = (float)((r1 * Math.Cos (theta1/radian_coversion)) + (r2 * Math.Cos (theta2/radian_coversion)));
			y_comp = (float)((r1 * Math.Sin (theta1/radian_coversion)) + (r2 * Math.Sin (theta2/radian_coversion)));
			r3 = (float)Math.Sqrt ((double)( x_comp * x_comp + y_comp * y_comp ));
			theta3 = -90 + (float)(radian_coversion)*(float)Math.Atan2(y_comp, x_comp);
		}

		z3.transform.localScale = new Vector3(1f, r3 , 1f);
		z3.transform.localPosition = new Vector3 (0, 0, 0);
		z3.transform.localRotation = Quaternion.Euler (0f, 0f, theta3);
	}
}